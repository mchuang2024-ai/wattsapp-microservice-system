// API Configuration - Update this to point to your backend
const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8080';

// Types
export interface ChargingSlot {
  id: string;
  type: 'Fast' | 'Slow';
  status: 'available' | 'occupied' | 'faulty' | 'maintenance';
  deposit: number;
  location: string;
  powerOutput: string;
  pricePerKwh: number;
}

export interface Booking {
  id: string;
  driverId: string;
  chargerId: string;
  slotId: string;
  startTime: string;
  endTime: string;
  status: 'pending' | 'active' | 'completed' | 'cancelled' | 'no-show' | 'late';
  deposit: number;
  createdAt: string;
  checkedInAt?: string;
  penalty?: number;
}

export interface Driver {
  id: string;
  name: string;
  email: string;
  lateCount: number;
  penaltyScore: number;
  isBlocked: boolean;
}

export interface FaultReport {
  bookingId: string;
  slotId: string;
  driverId: string;
  description: string;
}

export interface BookingRequest {
  driverId: string;
  chargerId: string;
  slotId: string;
  startTime: string;
  endTime: string;
  deposit: number;
}

// API Functions
export async function fetchSlots(status?: string): Promise<ChargingSlot[]> {
  const url = status 
    ? `${API_BASE_URL}/slots?status=${status}` 
    : `${API_BASE_URL}/slots`;
  const response = await fetch(url);
  if (!response.ok) throw new Error('Failed to fetch slots');
  return response.json();
}

export async function fetchSlotsByFilter(params: {
  location?: string;
  date?: string;
  startTime?: string;
  endTime?: string;
}): Promise<ChargingSlot[]> {
  const searchParams = new URLSearchParams();
  if (params.location) searchParams.append('location', params.location);
  if (params.date) searchParams.append('date', params.date);
  if (params.startTime) searchParams.append('startTime', params.startTime);
  if (params.endTime) searchParams.append('endTime', params.endTime);
  
  const response = await fetch(`${API_BASE_URL}/slots/available?${searchParams}`);
  if (!response.ok) throw new Error('Failed to fetch slots');
  return response.json();
}

export async function fetchDriverLateCount(driverId: string): Promise<{ lateCount: number; penaltyScore: number; isBlocked: boolean }> {
  const response = await fetch(`${API_BASE_URL}/Driver/${driverId}/late-count`);
  if (!response.ok) throw new Error('Failed to fetch driver info');
  return response.json();
}

export async function fetchPricingDeposit(): Promise<{ deposit: number }> {
  const response = await fetch(`${API_BASE_URL}/pricing/deposit`);
  if (!response.ok) throw new Error('Failed to fetch pricing');
  return response.json();
}

export async function createBooking(data: BookingRequest): Promise<Booking> {
  const response = await fetch(`${API_BASE_URL}/create-booking`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data),
  });
  if (!response.ok) {
    const error = await response.json();
    throw new Error(error.message || 'Failed to create booking');
  }
  return response.json();
}

export async function fetchBookings(driverId?: string): Promise<Booking[]> {
  const url = driverId 
    ? `${API_BASE_URL}/bookings?driverId=${driverId}` 
    : `${API_BASE_URL}/bookings`;
  const response = await fetch(url);
  if (!response.ok) throw new Error('Failed to fetch bookings');
  return response.json();
}

export async function handleNoShow(bookingId: string): Promise<{ penalty: number; message: string }> {
  const response = await fetch(`${API_BASE_URL}/handle-noshow/${bookingId}`, {
    method: 'POST',
  });
  if (!response.ok) throw new Error('Failed to handle no-show');
  return response.json();
}

export async function cancelBooking(bookingId: string): Promise<{ message: string }> {
  const response = await fetch(`${API_BASE_URL}/bookings/${bookingId}/cancel`, {
    method: 'POST',
  });
  if (!response.ok) throw new Error('Failed to cancel booking');
  return response.json();
}

export async function checkInBooking(bookingId: string): Promise<Booking> {
  const response = await fetch(`${API_BASE_URL}/bookings/${bookingId}/checkin`, {
    method: 'POST',
  });
  if (!response.ok) throw new Error('Failed to check in');
  return response.json();
}

export async function reportFault(data: FaultReport): Promise<{ message: string; refundAmount: number }> {
  const response = await fetch(`${API_BASE_URL}/reportfault`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data),
  });
  if (!response.ok) throw new Error('Failed to report fault');
  return response.json();
}

export async function fetchLocations(): Promise<string[]> {
  const response = await fetch(`${API_BASE_URL}/locations`);
  if (!response.ok) throw new Error('Failed to fetch locations');
  return response.json();
}
